module.exports = {
  singleQuote: true,
  traillingComma: 'all',
  allowParens: 'avoid',
};
