import marvel from './marvel/marvel';

export { marvel };
