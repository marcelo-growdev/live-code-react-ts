const privateKey = `${process.env.REACT_APP_MARVEL_PRIVATE_KEY}`;
const publicKey = `${process.env.REACT_APP_MARVEL_PUBLIC_KEY}`;

export { privateKey, publicKey };
